#!/usr/bin/perl
use List::Util qw(shuffle);

# start with a letter:
my @chars = ('a'..'z');
my $username = join '', (shuffle @chars)[0..1];

# random length between 6 and 10
my $length = int(rand(5)) + 6;

# more username characters
@chars = ('a'..'z', '0'..'9');
$username .= join '', (shuffle @chars)[0..($length)];

print $username;
print "\n";

# password needs digit, symbol, uppercase, lowercase
$length = int(rand(4)) + 1;
@chars = ('A'..'Z');
my $password = join '', (shuffle @chars)[0..$length];

$length = int(rand(3)) + 1;
@chars = ('0'..'9');
$password .= join '', (shuffle @chars)[0..$length];

$length = int(rand(3)) + 1;
@chars = ('^', '_', '@', '.', '*', '-', '%');
$password .= join '', (shuffle @chars)[0..$length];

$length = int(rand(5)) + 1;
@chars = ('a'..'z');
$password .= join '', (shuffle @chars)[0..$length];

print $password;
